﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WireCheck : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	//Detect collisions between the GameObjects with Colliders attached
	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.name == "Wire1")
		{
			Destroy(col.gameObject);
		}
	}



}
